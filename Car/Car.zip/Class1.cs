﻿namespace CarManufacturer
{
    internal class Class1
    {
    }
    class Car
    {
        public Car()
        {

        }
        private string _name;
        private string _model;
        private int _year;
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }


    }
}
